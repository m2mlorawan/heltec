visit IOTSHARING.COM for more
# esp32_webserver

This is for Arduino esp8266 I modified to adapt with esp32

Just put it in Arduino/libraries folder and run examples
