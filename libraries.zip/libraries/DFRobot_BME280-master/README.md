BME280
##DFRobot's Temperature、Pressure、Humidity and Approx altitude

Note: It is best to use on the 1.8.x version

 * @file bmp280test.ino
 * @brief DFRobot's Temperature、Pressure、Humidity and Approx altitude
 * @n [Get the module here]
 * @n This example read the Temperature、Pressure、Humidity and Altitude from BME280, and then print them
 * @n [Connection and Diagram]
 *
 * @copyright	[DFRobot](http://www.dfrobot.com), 2016
 * @copyright	GNU Lesser General Public License
 *
 * @author [yangyang]
 * @version  V1.0
 * @date  2017-7-5


# To Download, please click "Clone & Download ZIP"
